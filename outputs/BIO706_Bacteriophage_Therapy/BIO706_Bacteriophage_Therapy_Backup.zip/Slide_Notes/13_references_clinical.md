## Simple explanation — study aid, not spoken

These are the papers behind the two main clinical examples and the engineered-phage case. The BX004-A correction belongs with the original article.

## Graduate presentation script — optional, outside timed talk

The main clinical sources are Jault and colleagues' PhagoBurn trial, Weiner and colleagues' BX004-A trial and its correction, and Dedrick and colleagues' engineered-phage case. The slide provides the full titles, journal details, and DOIs. Study design and access limitations are documented in the research materials.

## Sources and optional technical detail — not spoken

Jault et al. (2019), Lancet Infect Dis 19:35–45, doi:10.1016/S1473-3099(18)30482-1. Weiner et al. (2025), Nat Commun 16:5579, doi:10.1038/s41467-025-60598-4. Weiner et al. (2026), Nat Commun 17:2057, doi:10.1038/s41467-026-70146-3. Dedrick et al. (2019), Nat Med 25:730–733, doi:10.1038/s41591-019-0437-z.