## Simple explanation — study aid, not spoken

For one patient, researchers found one naturally effective phage and modified or selected others to make a three-phage mixture. The patient improved during treatment, but this was not a controlled trial. The same mixture did not work well against other tested isolates, showing why personalization mattered.

## Graduate presentation script — spoken

Dedrick and colleagues illustrate the biotechnology behind personalization. Their patient was a fifteen-year-old lung-transplant recipient with disseminated drug-resistant Mycobacterium abscessus. Muddy had natural activity against the isolate. ZoeJ was converted into a lytic derivative by deleting a repressor gene. For BPs, a lytic derivative and host-range selection were needed. The resulting three-phage cocktail was administered intravenously, with topical treatment of accessible lesions. Treatment was associated with sternal wound closure and improvement of skin nodules during combined clinical care. This is a compelling demonstration of engineering and treatment feasibility, but it is one uncontrolled case. The cocktail did not efficiently kill other tested clinical isolates, so the authors explicitly cautioned against generalizing it as a treatment for all such infections.

## Sources and optional technical detail — not spoken

Dedrick et al. (2019), doi:10.1038/s41591-019-0437-z. Full text retrieved through official NCBI PMC. ZoeJΔ45 lacks repressor gene 45. BPsΔ33HTH-HRM10 includes a selected portal-gene 3 N270D substitution; do not call this tail-fiber redesign. Improved liver function was also reported. Association is not proof of cure, bacterial eradication, survival benefit or a phage-only causal effect.