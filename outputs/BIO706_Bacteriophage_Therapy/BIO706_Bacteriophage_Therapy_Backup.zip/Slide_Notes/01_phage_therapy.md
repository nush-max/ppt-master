## Simple explanation — study aid, not spoken

A bacteriophage is a virus that infects bacteria. Finding one that kills bacteria in a dish is only the beginning. We also need to make a clean, active product, get it to the infection, and show that it helps patients.

## Graduate presentation script — spoken

Bacteriophage therapy asks whether viruses of bacteria can become useful treatments for difficult bacterial infections. My argument has three parts: match the biology, control the product, and prove the benefit. I will first explain how a phage kills a susceptible bacterium, then follow the biotechnology needed to turn that activity into a treatment. Two trials and one personalized case will show why those three requirements are connected but distinct.

## Sources and optional technical detail — not spoken

Weiner et al. (2025), doi:10.1038/s41467-025-60598-4; Aslam et al. (2020), doi:10.1093/ofid/ofaa389. The illustration is an original simplified tailed-phage/bacterium schematic, not microscopy or a scale model.