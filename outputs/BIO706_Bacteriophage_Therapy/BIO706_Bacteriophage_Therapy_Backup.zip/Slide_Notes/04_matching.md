## Simple explanation — study aid, not spoken

The same bacterial species can contain strains that respond differently to a phage. Researchers test the patient's actual bacterium. A clear patch in a bacterial lawn is a useful clue, but it can occur without the phage making offspring. Plaque-based tests help distinguish productive infection from simple clearing.

## Graduate presentation script — spoken

The therapeutic unit is a particular phage interacting with a particular bacterial isolate. A conceptual workflow starts by identifying the infecting bacterium and testing candidate phages against that isolate. The key question is not simply whether a concentrated sample clears a patch of bacterial growth, but whether productive infection occurs. In a comparative experimental study, single-dilution spot tests often overestimated host range relative to efficiency-of-plating analyses. Clearing can occur without progeny production, including through lysis from without or abortive infection. Plaques and relative plating efficiency therefore provide complementary evidence about productive activity. These assays inform selection; they are not, by themselves, validated predictions of patient benefit. The figure is a conceptual explanation, not experimental plaque data or a proposed clinical susceptibility breakpoint.

## Sources and optional technical detail — not spoken

Khan Mirzaei and Nilsson (2015), doi:10.1371/journal.pone.0118557; Weiner et al. (2025), doi:10.1038/s41467-025-60598-4. Efficiency of plating compares plaque formation on a test isolate with a reference host under the assay conditions. The study does not show that every appropriately interpreted spot assay is useless.