## Simple explanation — study aid, not spoken

There are three separate checkpoints. A phage must infect the target bacterium, remain active and reach the infection, and then improve a meaningful patient outcome. A positive result at one checkpoint is useful, but it cannot substitute for evidence at the next one.

## Graduate presentation script — spoken

The evidence becomes more coherent when we organize it around three requirements. First is activity against the relevant isolate: the personalized case shows what matching and engineering can make possible. Second is active exposure at the infected site: PhagoBurn illustrates loss of titre, while BX004-A demonstrates pulmonary delivery. Third is a patient benefit attributable to treatment. That requires appropriate controls, sufficient sample size, and clinically meaningful endpoints, alongside microbiological measures. This three-part framework is my synthesis of the studies, not a scoring system validated by their authors. It explains why a successful plaque assay, phage recovery in sputum, and improvement during compassionate use are all informative but answer different questions. A convincing development program must connect those answers rather than treat them as interchangeable proof of efficacy.

## Sources and optional technical detail — not spoken

Presentation synthesis from Dedrick et al. (2019), Jault et al. (2019), Weiner et al. (2025), and Aslam et al. (2020). The proposed trial priorities are recommendations based on these limitations, not claims that one universal trial design suits every indication.