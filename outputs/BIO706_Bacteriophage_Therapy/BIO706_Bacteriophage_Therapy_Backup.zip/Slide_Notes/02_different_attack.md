## Simple explanation — study aid, not spoken

Bacteria can resist an antibiotic by destroying it, changing its target, or pumping it out. A phage attacks through a different route. But an antibiotic-resistant bacterium is not automatically vulnerable to any phage: the particular phage still has to recognize and infect it.

## Graduate presentation script — spoken

Antibiotic resistance creates a need for additional ways to attack bacteria. Mechanisms include enzymatic drug inactivation, alteration of a drug's target, and active efflux; the relevant mechanism depends on the drug and strain. A bacteriophage instead begins by recognizing a bacterial surface receptor and delivering its genome. If productive infection follows, the bacterium becomes the site of phage replication. That difference is the biological opportunity, but it is not a promise of universal susceptibility. Antibiotic resistance and susceptibility to a particular phage are distinct phenotypes. For example, the experimental phage OMKO1 interacts with an efflux-system surface component in Pseudomonas. We must therefore measure the phage–bacterium match rather than infer it from an antibiotic-resistance label.

## Sources and optional technical detail — not spoken

Munita and Arias (2016), doi:10.1128/microbiolspec.VMBF-0016-2015; Chan et al. (2016), doi:10.1038/srep26717. OMKO1 uses OprM; this is a specific example, not a receptor shared by all phages. Reduced permeability and target protection are additional resistance mechanisms discussed in the review but not exhaustively listed on the slide.