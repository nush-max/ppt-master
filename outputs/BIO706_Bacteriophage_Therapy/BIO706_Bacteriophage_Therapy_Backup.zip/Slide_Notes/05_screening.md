## Simple explanation — study aid, not spoken

There are two different questions: is this the right virus, and is this a suitable product? Genome checks look for known undesirable genes. Product checks look for contaminating bacteria, bacterial toxins, and enough active phage. Passing one type of check does not replace the others.

## Graduate presentation script — spoken

Matching establishes activity, but a therapeutic candidate must also pass biological and product-quality checks. In BX004-A development, genome screening supported a lytic lifestyle and screened for known toxin and antibiotic-resistance genes. Genomic identity and phenotype are complementary: sequence annotation does not eliminate every unknown function. Separately, product testing addresses sterility, endotoxin contamination, active titre, and stability. These are independent attributes. Removing viable production bacteria does not necessarily remove bacterial components such as endotoxin, and a sterile preparation may still have lost phage activity. The central biotechnology point is that an appropriate genome does not automatically make an appropriate medicine. Candidate characterization and final-product control must travel together through development and administration.

## Sources and optional technical detail — not spoken

Weiner et al. (2025), doi:10.1038/s41467-025-60598-4; Aslam et al. (2020), doi:10.1093/ofid/ofaa389. These are reported development and clinical-series practices, not a claim that one uniform regulatory standard applies to every country and indication.