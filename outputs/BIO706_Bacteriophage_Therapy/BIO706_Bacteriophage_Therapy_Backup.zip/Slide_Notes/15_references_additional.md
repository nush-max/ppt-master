## Simple explanation — study aid, not spoken

The matching-assay paper helps explain why a clear spot is not the same as productive infection. The other three papers provide additional clinical comparisons if they come up in questions.

## Graduate presentation script — optional, outside timed talk

Khan Mirzaei and Nilsson support the distinction between spot clearing and plating efficiency. Wright's otitis trial, Sarker's diarrhea trial, and Nir-Paz's TP-102 trial are available for discussion without making the main presentation a catalogue of trials. Their different populations, treatments and endpoints are reasons to compare carefully rather than pool their outcomes.

## Sources and optional technical detail — not spoken

Khan Mirzaei and Nilsson (2015), PLoS ONE 10:e0118557, doi:10.1371/journal.pone.0118557. Wright et al. (2009), Clin Otolaryngol 34:349–357, doi:10.1111/j.1749-4486.2009.01973.x. Sarker et al. (2016), EBioMedicine 4:124–137, doi:10.1016/j.ebiom.2015.12.023. Nir-Paz et al. (2025; electronic publication 2024), Med 6:100565, doi:10.1016/j.medj.2024.11.018.