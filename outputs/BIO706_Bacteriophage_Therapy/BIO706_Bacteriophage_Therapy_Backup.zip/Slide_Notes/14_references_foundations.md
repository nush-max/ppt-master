## Simple explanation — study aid, not spoken

These sources support the biological explanation, product-quality discussion, evolutionary example and antibiotic-resistance background. A review explains a field; an experimental paper tests a narrower claim.

## Graduate presentation script — optional, outside timed talk

The technical background draws on Aslam's clinical series, Chan's experimental evolutionary study, Kortright's phage-therapy review, and Munita and Arias's review of antibiotic resistance. Their roles differ: mechanistic and review evidence provides context, while uncontrolled clinical observations cannot establish a transferable treatment effect.

## Sources and optional technical detail — not spoken

Aslam et al. (2020), Open Forum Infect Dis 7:ofaa389, doi:10.1093/ofid/ofaa389. Chan et al. (2016), Sci Rep 6:26717, doi:10.1038/srep26717. Kortright et al. (2019), Cell Host Microbe 25:219–232, doi:10.1016/j.chom.2019.01.014. Munita and Arias (2016), Microbiol Spectr 4(2), doi:10.1128/microbiolspec.VMBF-0016-2015. Kortright framing was abstract-based; other sources' relevant full-text sections were consulted.