## Simple explanation — study aid, not spoken

Think of the bacterium as the place where the virus makes copies. The phage attaches, puts its genetic material inside, builds new phages, and releases them when the bacterium breaks open. This only happens when the host and conditions support infection. The drawing's few phages do not represent a measured number of offspring.

## Graduate presentation script — spoken

The lytic cycle explains both the attraction of phage therapy and its dependence on bacterial biology. First, adsorption attaches a compatible phage to receptors on the bacterial surface. In this simplified tailed-phage model, the genome then enters the cell. Intracellular replication and synthesis of viral components precede assembly of progeny particles. Finally, host lysis releases new phages, which may infect other susceptible bacteria. The illustrated number of progeny is schematic, not a measured burst size. Contrast this productive lytic outcome with temperate phages, which can establish a prophage state instead of immediately killing the host. Therapeutic selection therefore favors reliably lytic behavior or suitable lytic derivatives. Importantly, self-amplification is conditional. A phage must encounter a susceptible host in a permissive environment; administering it does not guarantee that amplification will occur in a patient. This dependence leads directly to the matching problem.

## Sources and optional technical detail — not spoken

Weiner et al. (2025), doi:10.1038/s41467-025-60598-4; Aslam et al. (2020), doi:10.1093/ofid/ofaa389. Temperate lifestyles are diverse: prophage integration is one possibility, not an exhaustive description of all phage states. Sarker et al. (2016), discussed in backup, provides a clinical example of limited intestinal amplification.