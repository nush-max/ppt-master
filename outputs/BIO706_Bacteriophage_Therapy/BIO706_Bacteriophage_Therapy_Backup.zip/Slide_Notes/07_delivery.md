## Simple explanation — study aid, not spoken

The phage needs to get to the bacteria while still active. Putting it on a wound, inhaling it, and injecting it into a vein are different delivery problems. A dose that enters the body may not all reach the infected area, and laboratory susceptibility does not guarantee success.

## Graduate presentation script — spoken

Route selection follows the infected compartment. PhagoBurn applied phages topically to accessible burn wounds. BX004-A used nebulization for chronic Pseudomonas infection in the lower respiratory tract. Selected personalized cases have used intravenous administration for disseminated infection, sometimes alongside topical treatment of accessible lesions. These routes are not interchangeable. The quantity administered is not the same as the quantity remaining active at the infection site. Delivery losses, clearance, neutralizing activity, and bacterial susceptibility can all affect exposure and response. Recovery of phages in sputum supports pulmonary delivery, but detection alone does not prove sustained replication. Likewise, activity against a cultured isolate does not guarantee success in the patient. We can now use two trials to ask which parts of this development chain were actually demonstrated.

## Sources and optional technical detail — not spoken

Jault et al. (2019), doi:10.1016/S1473-3099(18)30482-1; Weiner et al. (2025), doi:10.1038/s41467-025-60598-4; Aslam et al. (2020), doi:10.1093/ofid/ofaa389; Dedrick et al. (2019), doi:10.1038/s41591-019-0437-z. The neutralizing-serum observation in the case series lacked a baseline comparison, so it cannot establish causation or population frequency.