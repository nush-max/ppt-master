## Simple explanation — study aid, not spoken

The main takeaway is not simply that phages are promising. It is that their promise depends on the entire development chain. For discussion, consider whether killing more bacteria is enough if the patient feels no better or the infection returns.

## Graduate presentation script — spoken

Phage therapy is best understood as a biotechnology pipeline rather than a single antibacterial trick. Its biological specificity creates an opportunity, but also a matching requirement. Manufacturing and delivery must preserve activity, and clinical studies must show that this activity matters to patients. So the argument returns to three phrases: match the biology, control the product, and prove the benefit. The studies support continued development for defined indications, while cautioning against a broad claim that phages replace antibiotics. To open discussion: if bacterial burden falls but the patient does not improve, what has the treatment demonstrated, and what endpoint would you require in the next trial? The remaining slides provide the full references and optional evidence for discussion.

## Sources and optional technical detail — not spoken

Synthesis from Aslam et al. (2020), Jault et al. (2019), and Weiner et al. (2025). Main-talk timing excludes study aids, source details, reference pages and the backup slide. Rehearse using only the graduate presentation scripts.