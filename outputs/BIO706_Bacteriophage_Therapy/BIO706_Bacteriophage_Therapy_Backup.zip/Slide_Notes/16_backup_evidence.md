## Simple explanation — study aid, not spoken

This slide is only for questions. Small encouraging studies, unsuccessful trials, and rescue cases all teach something, but they do not combine into one reliable percentage of success. Phage resistance can sometimes carry an antibiotic-sensitivity tradeoff, but that is not guaranteed.

## Graduate presentation script — optional, outside timed talk

The broader literature reinforces the same evidence distinctions. Wright's twenty-four-person otitis trial reported preliminary improvement in a selected susceptible population. Sarker's interim cohort of one hundred twenty children showed no detected diarrhea benefit and limited gut amplification; it was not restricted to confirmed multidrug-resistant infections. Aslam reported seven author-defined successes among ten heterogeneous intravenous cases, with concurrent antibiotics and overlap with an earlier case report. TP-102 randomized nineteen participants and was underpowered to demonstrate healing superiority. Separately, Chan's laboratory work showed that OMKO1 resistance could alter an efflux-related antibiotic-sensitivity tradeoff. That is a preclinical evolutionary mechanism, not a universal clinical resensitization effect. These findings should be interpreted within their designs and indications rather than converted into a single success rate.

## Sources and optional technical detail — not spoken

Wright et al. (2009); Sarker et al. (2016); Aslam et al. (2020); Nir-Paz et al. (2025); Chan et al. (2016). Full references are on slides 14–15. TP-102's infected-subgroup 50% closure counts were 5/7 versus 1/3, P=0.500; these do not show superiority. Aslam's series includes the previously reported Acinetobacter case, so the two reports must not be counted as independent patients.