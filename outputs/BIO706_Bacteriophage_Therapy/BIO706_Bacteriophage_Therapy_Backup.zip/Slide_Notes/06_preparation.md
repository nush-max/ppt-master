## Simple explanation — study aid, not spoken

Phages need bacteria to multiply, so their production starts with a suitable bacterial host. The final material must then be cleaned, put into a usable formulation, and tested. Counting genetic material is not the same as showing that the phages can still infect bacteria.

## Graduate presentation script — spoken

Manufacturing translates the biological lifecycle into a product. At a conceptual level, phages are amplified using a suitable bacterial production host, followed by downstream separation and purification. Formulation then places the active particles in a vehicle compatible with the intended route. Release and stability testing assess identity, purity, and active concentration. Here, active titre concerns infective particles, commonly expressed as plaque-forming units, rather than simply the presence of viral material. BX004-A development also evaluated viability and delivery through a nebulizer. The lesson is that potency must survive the entire chain: manufacturing, storage, formulation, and administration. These are conceptual stages rather than a laboratory recipe. PhagoBurn will show why a product's activity at the point of treatment can be as important as the original phage selection.

## Sources and optional technical detail — not spoken

Weiner et al. (2025), doi:10.1038/s41467-025-60598-4; Aslam et al. (2020), doi:10.1093/ofid/ofaa389; Jault et al. (2019), doi:10.1016/S1473-3099(18)30482-1. No operating parameters or procedural manufacturing recommendations are supplied.